package com.school.hub.navigation

object Routes {
    const val HOME = "home"
    const val CHEATS = "cheats"
    const val SCHEDULE = "schedule"
    const val HOMEWORK = "homework"
    const val AI = "ai"
    const val TRANSLATOR = "translator"
    const val SYNC = "sync"
    const val CHEAT_DETAIL = "cheat/{id}"
    const val CHEAT_EDIT = "cheat_edit?id={id}"

    fun cheatDetail(id: Long) = "cheat/$id"
    fun cheatEdit(id: Long? = null) = if (id == null) "cheat_edit" else "cheat_edit?id=$id"
}
